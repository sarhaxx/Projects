# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
master_depression_joined_norm_by_country = dataiku.Dataset("master_depression_joined_norm_by_country")
master_depression_joined_norm_by_country_df = master_depression_joined_norm_by_country.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

depressionVSsuicides_df = master_depression_joined_norm_by_country_df # For this sample code, simply copy input to output
for column in depressionVSsuicides_df:
    if column in {"Depression_sum","Anxietydisorders_sum","Depression_sum","suicides/100k pop_sum"}:
        depressionVSsuicides_df[column] = (depressionVSsuicides_df[column] - depressionVSsuicides_df[column].min()) / (depressionVSsuicides_df[column].max() - depressionVSsuicides_df[column].min())  


# Write recipe outputs
depressionVSsuicides = dataiku.Dataset("depressionVSsuicides")
depressionVSsuicides.write_with_schema(depressionVSsuicides_df)
