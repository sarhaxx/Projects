# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
suicidedataextrafestures_by_year = dataiku.Dataset("suicidedataextrafestures_by_year")
suicidedataextrafestures_by_year_df = suicidedataextrafestures_by_year.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

suicide_by_year_normalized_df = suicidedataextrafestures_by_year_df # For this sample code, simply copy input to output
for column in suicide_by_year_normalized_df:
    if column in {"GDPpcapital_avg","suicidesper100k_avg"}:
        suicide_by_year_normalized_df[column] = (suicide_by_year_normalized_df[column] - suicide_by_year_normalized_df[column].min()) / (suicide_by_year_normalized_df[column].max() - suicide_by_year_normalized_df[column].min())  
#suicide_by_year_normalized_df["% Religious"]=suicide_by_year_normalized_df["% Religious"]/100


# Write recipe outputs
suicide_by_year_normalized = dataiku.Dataset("suicide_by_year_normalized")
suicide_by_year_normalized.write_with_schema(suicide_by_year_normalized_df)
