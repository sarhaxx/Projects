# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
master_depression_joined = dataiku.Dataset("master_depression_joined")
master_depression_joined_df = master_depression_joined.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

master_depression_joined_norm_df = master_depression_joined_df # For this sample code, simply copy input to output

for column in master_depression_joined_norm_df:
    if column in {"Depression","Anxietydisorders","Depression","suicides/100k pop"}:
        master_depression_joined_norm_df[column] = (master_depression_joined_norm_df[column] - master_depression_joined_norm_df[column].min()) / (master_depression_joined_norm_df[column].max() - master_depression_joined_norm_df[column].min())  




# Write recipe outputs
master_depression_joined_norm = dataiku.Dataset("master_depression_joined_norm")
master_depression_joined_norm.write_with_schema(master_depression_joined_norm_df)
