# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
country_religion_joined = dataiku.Dataset("country_religion_joined")
country_religion_joined_df = country_religion_joined.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

country_religion_normalized_df = country_religion_joined_df # For this sample code, simply copy input to output

for column in country_religion_normalized_df:
    if column not in {"country","% Religious"}:
        country_religion_normalized_df[column] = (country_religion_normalized_df[column] - country_religion_normalized_df[column].min()) / (country_religion_normalized_df[column].max() - country_religion_normalized_df[column].min())  
country_religion_normalized_df["% Religious"]=country_religion_normalized_df["% Religious"]/100

# Write recipe outputs
country_religion_normalized = dataiku.Dataset("country_religion_normalized")
country_religion_normalized.write_with_schema(country_religion_normalized_df)
